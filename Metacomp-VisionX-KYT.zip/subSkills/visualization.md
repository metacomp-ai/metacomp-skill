# Data Visualization — Mandatory, Never Skippable

Every security report MUST render a visualization widget. This is a hard requirement — not optional, not conditional on data richness.

## Enforcement Rules

- ❌ Do NOT finish a response without calling `show_widget`
- ❌ Do NOT skip charts because data is sparse, missing, or already shown in a previous turn
- ❌ Do NOT treat visualization as optional — it is as mandatory as the text report
- ✅ Always call `read_me(["chart"])` before the first `show_widget` call in each response
- ✅ Every new MCP tool result requires its own fresh visualization — previous turns do NOT satisfy this
- ✅ If about to end without `show_widget` — stop and call it immediately

## Per-Response Rule

Visualization is **per-response**, not per-conversation. Each time MCP results are returned, follow the full sequence for the report type:

**Transaction:** ① Analysis Preface → ② show_widget #1 (doughnut + bar + radar) → ③ Text report

**Wallet:** ① Analysis Preface → ② show_widget #1 (metric cards + exposure tables + spider charts) → ③ show_widget #2 (Risk Conclusion Card) → ④ Fund Flow markdown → ⑤ Text report (all 5 sub-sections) → ⑥ show_widget #3 (Cross-Vendor tables) → ⑦ Comprehensive Summary → ⑧ Exposure detail tables

## Chart Fallback Rule

- Empty array → gray placeholder slice/bar labeled "No data" (transaction charts)
- Null field → zero baseline
- Spider charts: render only when **3+ valid entries** exist (see chart-spec.md). Fewer than 3 → show `数据维度不足，暂不展示图表` placeholder instead

---

## Self-Check Before Completing Any Response

**Transaction reports:**
> ☐ `show_widget` called in THIS response?
> ☐ Widget includes Doughnut chart (risk vs clean ratio)?
> ☐ Widget includes Bar chart (risk score vs thresholds)?
> ☐ Widget includes Radar chart (multi-dimension risk profile)?

**Wallet reports:**
> ☐ show_widget call #1: main widget (metric cards + exposure tables + spider charts)?
> ☐ Widget includes 4 High Risk Exposure Tables (2×2)?
> ☐ `directIncoming`: counted `totalValueUsd > 0` entries → chart (≥3) or placeholder (<3)?
> ☐ `indirectIncoming`: counted `totalValueUsd > 0` entries → chart (≥3) or placeholder (<3)?
> ☐ `directOutgoing`: counted `totalValueUsd > 0` entries → chart (≥3) or placeholder (<3)?
> ☐ `indirectOutgoing`: counted `totalValueUsd > 0` entries → chart (≥3) or placeholder (<3)?
> ☐ show_widget call #2: 🚨 Risk Conclusion Card (dedicated call, NOT combined with #1)?
> ☐ 💰 Fund Flow Summary table rendered as standalone markdown (after Risk Conclusion Card)?
> ☐ 🔐 Wallet Security Report text rendered — all 5 sub-sections present?
>    — Basic Info table?
>    — Transaction Timeline table + activity comment?
>    — Risk Exposure Breakdown table?
>    — Tainted Exposure Summary table (omit only if field is absent)?
>    — High Risk Categories Associated (plain text labels)?
> ☐ show_widget call #3: 🔍 Cross-Vendor Risk Comparison (4 HTML tables — NEVER plain text)?
> ☐ 📋 Comprehensive Summary rendered (4–6 sentences)?
> ☐ Exposure Detail Tables (Step ⑧) rendered after summary (see wallet-exposure-tables.md)?

If any box is unchecked → response is incomplete. Render the missing element before finishing.

---

## Chart Type Mapping

| Data | Chart Type | Content |
|---|---|---|
| `riskSources[].ratio` + `(100 - ratio)` | Doughnut | Risk vs clean fund ratio |
| `txRiskLevel` vs thresholds | Bar | Risk score vs Low/High thresholds |
| `directExposure` + `riskSources` | Radar | Multi-dimension risk profile |
| `directIncoming[]` (wallet) | Spider Chart | Direct Incoming Exposure — one axis per risk category |
| `indirectIncoming[]` (wallet) | Spider Chart | Indirect Incoming Exposure |
| `directOutgoing[]` (wallet) | Spider Chart | Direct Outgoing Exposure |
| `indirectOutgoing[]` (wallet) | Spider Chart | Indirect Outgoing Exposure |
| `highRiskCategories[]` (wallet) | HTML pill tags (inside widget) | Risk category badges |

Transaction charts are mandatory. Spider charts (wallet) are conditional — render only when 3+ valid entries exist, otherwise show placeholder (see Chart Fallback Rule above).

---

## Complete Output Order

**Transaction report — full sequence:**
```
① Analysis Preface (`>` blockquote with 🔬, see transaction-report.md / wallet-report.md)  ← FIRST

② [MANDATORY] Visualization widget
   — read_me(["chart"]) first, then show_widget
   — Metric cards (risk level badge, USD value, key ratios)
   — Row 1: Doughnut + Bar  ← side by side, 50/50
   — Row 2: Radar  ← FULL WIDTH, its own row, NEVER alongside row 1

   ← Incomplete until rendered

③ 🔍 Transaction Security Report (text)
   — Transaction info table
   — ⚠️ Risk Sources table
   — 📋 Comprehensive Summary (4–5 sentences)
```

**Wallet report — full sequence:**
```
① Analysis Preface (`>` blockquote with 🔬, see wallet-report.md)  ← FIRST

② [MANDATORY] Visualization widget  ← show_widget call #1
   — read_me(["chart"]) first, then show_widget
   — Metric cards (risk level, total incoming, total outgoing, wallet balance `data.extra.walletBalance`)
   — High Risk Exposure Tables (4 tables, 2×2):
       Row A: [ Incoming Direct ]  [ Incoming Indirect ]
       Row B: [ Outgoing Direct ]  [ Outgoing Indirect ]
   — Spider row 1: Direct Incoming (left) + Indirect Incoming (right)
   — Spider row 2: Direct Outgoing (left) + Indirect Outgoing (right)

③ [MANDATORY] 🚨 Risk Conclusion Card  ← show_widget call #2
   — DEDICATED call, do NOT combine with ②

④ [MANDATORY] 💰 Fund Flow Summary table — standalone markdown

⑤ [MANDATORY] 🔐 Wallet Security Report (text) — all 5 sub-sections required:
   — Basic Info table
   — Transaction Timeline table + activity comment
   — Risk Exposure Breakdown table
   — Tainted Exposure Summary table (omit only if field is absent in data)
   — High Risk Categories Associated (plain text labels only)

⑥ [MANDATORY] 🔍 Cross-Vendor Risk Comparison  ← show_widget call #3
   — 4 HTML tables (Direct Incoming / Direct Outgoing / Indirect Incoming / Indirect Outgoing)
   — ⛔ MUST use show_widget — NEVER output as plain text (HTML will render as raw code)

⑦ [MANDATORY] 📋 Comprehensive Summary (text, 4–6 sentences)

⑧ [MANDATORY] Exposure Detail Tables — see wallet-exposure-tables.md
```

---

## Widget Layout Rules

### ❌ Never do these (cause truncation or raw-text bugs)

- ❌ **No `<iframe>`** — widget must be inline HTML, not a framed document
- ❌ **No fixed height on outer container** — no `height:`, `max-height:`, `overflow:scroll/auto` on wrappers
- ❌ **Do NOT output High Risk Categories HTML as standalone text** — must be embedded in `show_widget` payload
- ❌ **No scroll container** — flat vertical stack only

### ✅ Correct outer structure

```html
<div style="width:100%; font-family:sans-serif">
  <!-- metric cards row -->
  <!-- high risk exposure tables (4 tables, 2×2) — wallet only -->
  <!-- chart sections, each taking natural height -->
</div>
```

### Transaction widget HTML structure

```html
<div style="width:100%; font-family:sans-serif">
  <div style="display:flex; gap:12px; margin-bottom:16px">
    <!-- card per metric -->
  </div>

  <!-- Row 1: Doughnut + Bar side by side -->
  <div style="display:flex; gap:16px; margin-bottom:16px">
    <div style="flex:1; min-width:0"><!-- Doughnut canvas --></div>
    <div style="flex:1; min-width:0"><!-- Bar canvas --></div>
  </div>

  <!-- Row 2: Radar ALONE, full width — NEVER inside row 1 flex container -->
  <div style="width:100%; margin-bottom:16px">
    <div style="position:relative; width:100%; height:280px">
      <!-- Radar canvas -->
    </div>
  </div>
</div>
```

> ❌ Do NOT place the Radar canvas inside the same `display:flex` as Doughnut and Bar — it will be compressed.

---

## Chart Styling Rules

- Custom HTML legend beside each chart — **never** use Chart.js default legend
- Doughnut cutout: `52%`
- Bar border radius: `6px`, no border
- All axes: hide border line (`border: { display: false }`), show subtle grid (`rgba(0,0,0,0.07)` light / `rgba(255,255,255,0.08)` dark)
- Font ticks: `11–12px`, `textColor` from `matchMedia('prefers-color-scheme')`
- Canvas wrapper: `<div style="position:relative;width:100%;height:Xpx">` — never set height on canvas element itself
- Metric cards: `background: var(--color-background-secondary)`, `border-radius: var(--border-radius-md)`, `padding: 1rem`, centered text

---

## High-Risk Category Summary Tables — 4 Tables, MANDATORY, Every Wallet Response (Inside Widget)

> ⚠️ **These are NOT the same as the Exposure Detail Tables in `wallet-exposure-tables.md` (Step ⑥).** These tables go **inside the `show_widget` payload** and show only `isHighRisk=true` entries, with 9 fixed category rows (zero for missing). The Step ⑥ tables come after the text report and show ALL entries.

Render **4 HTML tables** inside the `show_widget` payload in 2×2 layout. Never as standalone text or pill tags.

### Layout

```
Row A (side by side):  [ Incoming Direct ]   [ Incoming Indirect ]
Row B (side by side):  [ Outgoing Direct ]   [ Outgoing Indirect ]
```

### Rules

- ❌ Do NOT render as pill tags, text labels, or markdown — HTML tables only
- ❌ Do NOT place outside the `show_widget` payload
- ✅ Fixed 9-row list in every table — show `0` for categories with no exposure
- ✅ Match `tagTypeVerbose` to category name; if not found → `0`

### Fixed category row order (always 9 rows, always this order)

Sanctions → High Risk Organisation → Theft → Malware → Scams → Extortion → Coin Mixer → Darknet → Gambling

### Data source per table

| Table | Data Array | % Column Header |
|---|---|---|
| Incoming Direct | `data.extra.directIncoming` (isHighRisk=true entries) | High-Risk % of Total Received |
| Incoming Indirect | `data.extra.indirectIncoming` (isHighRisk=true entries) | High-Risk % of Total Received |
| Outgoing Direct | `data.extra.directOutgoing` (isHighRisk=true entries) | High-Risk % of Total Sent |
| Outgoing Indirect | `data.extra.indirectOutgoing` (isHighRisk=true entries) | High-Risk % of Total Sent |

### Value Formatting

- Amount > 0: `≈ {value with comma thousands separator}` e.g. `≈ 19,653,080.62`
- Amount = 0 or missing: `0`
- Ratio > 0: `{value} %` (space before %) e.g. `1.28 %`
- Ratio = 0 or missing: `0`

### HTML Template

```html
<!-- Pair A: Incoming Direct + Incoming Indirect side by side -->
<div style="display:flex; gap:16px; margin-bottom:24px">

  <!-- Table 1: Incoming Direct -->
  <div style="flex:1; min-width:0">
    <div style="margin-bottom:8px; font-size:14px; font-weight:600">
      <span style="color:#4CAF50">Incoming</span>
      <span style="color:#333"> Direct Exposure to High Risk Sources</span>
    </div>
    <table style="width:100%; border-collapse:collapse; font-size:13px">
      <thead>
        <tr style="background:#555; color:#fff">
          <th style="padding:8px 10px; text-align:left; font-weight:600">High Risk Sources</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">Amount (USD)</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">High-Risk % of Total Received</th>
        </tr>
      </thead>
      <tbody>
        <!-- 9 rows, alternating background: #fff / #f5f5f5 -->
        <tr style="background:#fff">
          <td style="padding:7px 10px">Sanctions</td>
          <td style="padding:7px 10px; text-align:right">0</td>
          <td style="padding:7px 10px; text-align:right">0</td>
        </tr>
        <!-- repeat for: High Risk Organisation, Theft, Malware, Scams, Extortion, Coin Mixer, Darknet, Gambling -->
      </tbody>
    </table>
  </div>

  <!-- Table 2: Incoming Indirect -->
  <div style="flex:1; min-width:0">
    <div style="margin-bottom:8px; font-size:14px; font-weight:600">
      <span style="color:#4CAF50">Incoming</span>
      <span style="color:#333"> Indirect Exposure to High Risk Sources</span>
    </div>
    <table style="width:100%; border-collapse:collapse; font-size:13px">
      <thead>
        <tr style="background:#555; color:#fff">
          <th style="padding:8px 10px; text-align:left; font-weight:600">High Risk Sources</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">Amount (USD)</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">High-Risk % of Total Received</th>
        </tr>
      </thead>
      <tbody>
        <!-- 9 rows from indirectIncoming (isHighRisk=true), alternating background: #fff / #f5f5f5 -->
        <tr style="background:#fff">
          <td style="padding:7px 10px">Sanctions</td>
          <td style="padding:7px 10px; text-align:right">0</td>
          <td style="padding:7px 10px; text-align:right">0</td>
        </tr>
        <!-- repeat for: High Risk Organisation, Theft, Malware, Scams, Extortion, Coin Mixer, Darknet, Gambling -->
      </tbody>
    </table>
  </div>

</div>

<!-- Pair B: Outgoing Direct + Outgoing Indirect side by side -->
<div style="display:flex; gap:16px; margin-bottom:24px">

  <!-- Table 3: Outgoing Direct -->
  <div style="flex:1; min-width:0">
    <div style="margin-bottom:8px; font-size:14px; font-weight:600">
      <span style="color:#FF8C00">Outgoing</span>
      <span style="color:#333"> Direct Exposure to High Risk Sources</span>
    </div>
    <table style="width:100%; border-collapse:collapse; font-size:13px">
      <thead>
        <tr style="background:#555; color:#fff">
          <th style="padding:8px 10px; text-align:left; font-weight:600">High Risk Sources</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">Amount (USD)</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">High-Risk % of Total Sent</th>
        </tr>
      </thead>
      <tbody>
        <!-- 9 rows from directOutgoing (isHighRisk=true), alternating background: #fff / #f5f5f5 -->
        <tr style="background:#fff">
          <td style="padding:7px 10px">Sanctions</td>
          <td style="padding:7px 10px; text-align:right">0</td>
          <td style="padding:7px 10px; text-align:right">0</td>
        </tr>
        <!-- repeat for: High Risk Organisation, Theft, Malware, Scams, Extortion, Coin Mixer, Darknet, Gambling -->
      </tbody>
    </table>
  </div>

  <!-- Table 4: Outgoing Indirect -->
  <div style="flex:1; min-width:0">
    <div style="margin-bottom:8px; font-size:14px; font-weight:600">
      <span style="color:#FF8C00">Outgoing</span>
      <span style="color:#333"> Indirect Exposure to High Risk Sources</span>
    </div>
    <table style="width:100%; border-collapse:collapse; font-size:13px">
      <thead>
        <tr style="background:#555; color:#fff">
          <th style="padding:8px 10px; text-align:left; font-weight:600">High Risk Sources</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">Amount (USD)</th>
          <th style="padding:8px 10px; text-align:right; font-weight:600">High-Risk % of Total Sent</th>
        </tr>
      </thead>
      <tbody>
        <!-- 9 rows from indirectOutgoing (isHighRisk=true), alternating background: #fff / #f5f5f5 -->
        <tr style="background:#fff">
          <td style="padding:7px 10px">Sanctions</td>
          <td style="padding:7px 10px; text-align:right">0</td>
          <td style="padding:7px 10px; text-align:right">0</td>
        </tr>
        <!-- repeat for: High Risk Organisation, Theft, Malware, Scams, Extortion, Coin Mixer, Darknet, Gambling -->
      </tbody>
    </table>
  </div>

</div>
```

# Transaction Report Formatting

## Analysis Preface

Output this FIRST — before the visualization widget and before any other content.

Render as a `>` blockquote opening with the 🔬 emoji. Write fresh each time in the user's language. The preface MUST contain **three separate paragraphs** in the order below. Each paragraph is independently required — do NOT merge them.

---

### Preface Paragraph 1 — Data Sources

Name all six vendors explicitly: **Chainalysis, Elliptic, TRM, Merkle Science, Beosin, and SlowMist**. Explain that cross-verification across multiple vendors eliminates individual blind spots. (1–2 sentences)

---

### Preface Paragraph 2 — Methodology ⛔ NEVER SKIP OR COMPRESS

This paragraph is the most critical. Write a **minimum of 3 full sentences** that explicitly cover ALL four points below. DO NOT compress them into a single clause.

Required content (all four must appear):
- **Layer 1**: the analysis directly checks whether the wallet/transaction has contact with flagged addresses
- **Layer 2**: fund flows are traced forward and backward across unlimited on-chain hops until the trail ends or connects to a flagged entity
- **Taint ratios** are calculated at each hop depth and compared against wallet-level cumulative thresholds
- The **final risk rating reflects both layers** combined

⛔ **Keyword enforcement**: The paragraph MUST contain the phrases "Layer 1", "Layer 2", and "taint" (or equivalents in the response language). If any are absent, the paragraph is incomplete — rewrite before continuing.

---

### Preface Paragraph 3 — Research Basis + Contextual Tone

Cite at least one concrete figure from: MetaComp Research, "Relative Effectiveness of On-Chain AML/CFT Know-Your-Transaction (KYT) Tools" (July 2025), based on 7,000 randomly selected Ethereum and Tron transactions. Always attribute to "MetaComp Research (July 2025)".

Key findings to draw from (pick what's most relevant to this case):
- 1 vendor alone: false-clean rate up to 25% at medium-high risk threshold
- 2 vendors: false-clean rate 7–22% depending on combination
- 3+ vendors: false-clean rate drops below 0.25% — the standard this report meets
- Tron carries ~10× higher sanctions exposure than Ethereum (6.95% vs 0.70% severe risk)
- 20%+ of sampled Tron transactions rated medium-high risk or above

Connect the figure to this specific case — never cite numbers in isolation.

Tone guidance:
- Low risk → explain why the clean rating is trustworthy; reference false-clean rates
- Tron network → reference the Tron/ETH risk ratio
- High risk / multiple categories → reference multi-vendor parallel scanning
- Indirect exposure → explain the unlimited-hop tracing process

---

⛔ **PREFACE COMPLETION GATE — verify before calling show_widget:**
- [ ] Paragraph 1 written — named all six vendors?
- [ ] Paragraph 2 written — contains "Layer 1", "Layer 2", and "taint"? Minimum 3 sentences?
- [ ] Paragraph 3 written — cites at least one figure with source?

If any box is unchecked → complete the missing paragraph(s) before proceeding. Do NOT call show_widget until all three are done.

---

> **⚠️ OUTPUT ORDER — Call `read_me(["chart"])` + `show_widget` (metric cards + doughnut + bar + radar) BEFORE writing any content below.** See `visualization.md` + `chart-spec.md`. The response is **incomplete** until `show_widget` has been called first.

## 🔍 Transaction Security Report

**If `data.extra.selectedTx` is `null` or an empty array:**
- Show: "Transaction details were not returned in the response. The overall risk level is: `data.level`."
- Still render the visualization widget with whatever fields are available.

**If `data.extra.selectedTx` has entries**, for each transaction in the array:

---

**Transaction:** `txHash` (truncated to first 10 + last 4 chars)

| Field | Detail |
|---|---|
| Date | `date` |
| Direction | `direction` (received / sent) |
| Asset | `asset.asset` |
| Amount | `asset.amount` |
| USD Value | `$asset.usdValue` USD |
| From | `fromAddress` |
| To | `toAddress` |
| Risk Level | 🟢 Low / 🟡 Medium / 🟠 Medium-High / 🔴 High — based on `txRiskLevel` |
| Direct Exposure | Yes / No |

**⚠️ Risk Sources**

| Risk Type | Ratio | Interpretation |
|---|---|---|
| `source` | `ratio` | < 5%: low indirect, likely residual. 5–20%: moderate concern. > 20%: significant risk. |

For each risk source present, add one sentence explaining practical implications (e.g. "A Sanctions exposure of 1.47% means a small portion of funds traces back to sanctioned addresses through several hops.").

If `riskSources` is empty or all "N/A": "✅ No risk sources identified. The transaction shows no traceable links to known risky entities."

**📋 Comprehensive Summary** (4–5 sentences)

1. Overall safety verdict — is this transaction safe?
2. What the risk level means for the user in practical terms
3. Detailed explanation of each risk source: what it implies, how seriously to treat it
4. Whether the transaction direction (sent/received) changes the risk implication
5. Actionable recommendation: safe to proceed / proceed with caution / flag for review / avoid

---

## Radar Chart Dimensions (Transaction Reports)

Use 5 fixed axes, derive scores 0–100 from MCP response data.
Axis label language follows response language.

| English Label | Chinese Label | Derivation |
|---|---|---|
| Compliance | 合规性 | `100 - (sanctions_ratio * 10)` capped 0–100 |
| Fund Cleanliness | 资金清洁度 | `100 - total_risk_ratio` |
| Transparency | 交易透明度 | 90 if `directExposure == "No"` else 40 |
| Address Trust | 地址可信度 | 65 baseline; lower if high-risk categories present |
| Network Safety | 网络安全性 | 88 (Ethereum/Bitcoin), 75 (Tron) |

---

## Handling Errors

- `data.success === false` or `code !== 0` → tell the user the check failed; suggest retrying or contacting support at metacomp.ai
- 401 error → API key invalid or expired; prompt to re-authenticate or apply for a new key at metacomp.ai
- Unsupported network → only Bitcoin, Ethereum, and Tron are currently supported

---

## Example Prompts

**Wallet only:**
- "帮我检查一下这个钱包是否安全：`0x559432E18b281731c054cD703D4B49872BE4ed53`"
- "Check if this Ethereum wallet is involved in any scams: `0x...`"
- "Analyze wallet risk on Tron: `TXxxxxxx`"

**Transaction (always ask first — no exceptions):**
- "Is this transaction safe? hash: `0x524db269...`, I received 11 USDT from `0x05D9...`"
- "Check this transaction: hash `0x524db269...`, from `0xAAA...` to `0xBBB...`"
- "我转了一笔给 `TXxxxxxx`，这个地址有没有问题？"
→ Ask first: "Are you the sender or the recipient?"
→ Recipient → `get_wallet_security` on `from` address
→ Sender → `get_wallet_security` on `to` address

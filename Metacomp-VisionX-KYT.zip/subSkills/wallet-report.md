# Wallet Report Formatting

## [MANDATORY] Step ①: Analysis Preface

> **⚠️ Skip this entire step if this wallet report is the counterparty wallet shown after a transaction report in the same response.** The Analysis Preface was already output for the transaction report — do not repeat it.

Output this FIRST — before the visualization widget and before any other content. (Standalone wallet checks only.)

Render as a `>` blockquote opening with the 🔬 emoji. Write fresh each time in the user's language. The preface MUST contain **two separate paragraphs** in the order below. Each paragraph is independently required — do NOT merge them. Do NOT include methodology (Layer 1 / Layer 2 / taint ratios) — that belongs to the transaction report only.

---

### Preface Paragraph 1 — Data Sources

Name all six vendors explicitly: **Chainalysis, Elliptic, TRM, Merkle Science, Beosin, and SlowMist**. Explain that cross-verification across multiple vendors eliminates individual blind spots. (1–2 sentences)

---

### Preface Paragraph 2 — Research Basis + Contextual Tone

Cite at least one concrete figure from: MetaComp Research, "Relative Effectiveness of On-Chain AML/CFT Know-Your-Transaction (KYT) Tools" (July 2025), based on 7,000 randomly selected Ethereum and Tron transactions. Always attribute to "MetaComp Research (July 2025)".

Key findings to draw from (pick what's most relevant to this case):
- 1 vendor alone: false-clean rate up to 25% at medium-high risk threshold
- 2 vendors: false-clean rate 7–22% depending on combination
- 3+ vendors: false-clean rate drops below 0.25% — the standard this report meets
- Tron carries ~10× higher sanctions exposure than Ethereum (6.95% vs 0.70% severe risk)
- 20%+ of sampled Tron transactions rated medium-high risk or above

Connect the figure to this specific case — never cite numbers in isolation.

Tone guidance:
- Low risk → explain why the clean rating is trustworthy; reference false-clean rates
- Tron network → reference the Tron/ETH risk ratio
- High risk / multiple categories → reference multi-vendor parallel scanning
- Indirect exposure → explain the unlimited-hop tracing process

---

⛔ **PREFACE COMPLETION GATE — verify before calling show_widget:**
- [ ] Paragraph 1 written — named all six vendors?
- [ ] Paragraph 2 written — cites at least one figure with source?

If any box is unchecked → complete the missing paragraph(s) before proceeding. Do NOT call show_widget until both are done.

---

---

> ⚠️ **OUTPUT ORDER GATE — Steps ②③ must come before this section.**
> Before writing any content below, confirm both are complete:
> - ② `show_widget` called (metric cards + 4 High-Risk Category Summary Tables (widget-internal) + spider charts)
> - ③ 🚨 Risk Conclusion Card rendered via a **dedicated second `show_widget` call** (NOT combined with ②)
>
> If ② or ③ is not yet done → stop here, complete them, then return to this section.

---

### 💰 Step ④: Fund Flow Summary

> **[MANDATORY]** Render this table now as standalone markdown — immediately after the 🚨 Risk Conclusion Card. Do NOT defer to the widget.
> ❌ Do NOT skip the Balance row. If `data.extra.walletBalance` is absent or null, display "暂无".

| Metric | Amount |
|:---|---:|
| 📥 Total Incoming | `$data.extra.totalIncoming` USD |
| 📤 Total Outgoing | `$data.extra.totalOutgoing` USD |
| 💼 Balance | `$data.extra.walletBalance` USD |

---

### 🔐 Wallet Security Report (Step ⑤)

**Basic Info**

| Field | Detail |
|---|---|
| Address | `data.address` |
| Network | `data.network` |
| Overall Risk Level | 🟢 Low / 🟡 Medium / 🟠 Medium-High / 🔴 High — based on `data.level` |

---

**Transaction Timeline**

| Field | Detail |
|---|---|
| Earliest Transaction | `data.extra.earliestTransactionTime` |
| Latest Transaction | `data.extra.latestTransactionTime` |
| Total Incoming | `$data.extra.totalIncoming` USD |
| Total Outgoing | `$data.extra.totalOutgoing` USD |

Briefly comment on the wallet's activity span and transaction volume — e.g. whether it's a long-standing active wallet or a newly created one, and whether the volume is notable.

---

**Risk Exposure Breakdown**

| Direction | Total | Low Risk | High Risk | High Risk % |
|---|---|---|---|---|
| Incoming | `$incomingRiskExposureBreakdown.totalAmount` USD | `$...lowRiskAmount` USD | `$...highRiskAmount` USD | `highRisk/total*100`% |
| Outgoing | `$outgoingRiskExposureBreakdown.totalAmount` USD | `$...lowRiskAmount` USD | `$...highRiskAmount` USD | `highRisk/total*100`% |

---

**Tainted Exposure Summary** *(omit entire table if field is absent)*

| Direction | Tainted Amount |
|---|---|
| Incoming | `$highRiskSumOfTaintedExposure.incoming` USD |
| Outgoing | `$highRiskSumOfTaintedExposure.outgoing` USD |

If any high-risk amount > 0, comment on the percentage of total flow at risk and whether that warrants concern.

---

**High Risk Categories Associated**

List all items in `data.extra.highRiskCategories` as plain text labels, e.g.:
`Sanctions · Theft · Malware · Darknet`

> Styled pill tags are rendered in the visualization widget — use plain text here only.

For each category present, add one sentence explaining practical implications:

- **Sanctions**: Funds may be linked to individuals or entities under government sanctions (OFAC, EU, UN).
- **Theft**: Association with addresses flagged for stolen funds or hack proceeds.
- **Malware**: Linked to wallets used in ransomware or malware payment schemes.
- **Darknet**: Connected to darknet marketplace activity.
- **Scams**: Associated with known phishing, fraud, or rug-pull operations.
- **High Risk Organisation**: Interaction with entities classified as high-risk financial counterparties.
- **Coin Mixer**: Funds passed through mixing/tumbling services used to obscure transaction trails.
- **Extortion**: Linked to addresses associated with extortion or blackmail payments.
- **Gambling**: Connected to unlicensed or high-risk online gambling platforms.

If the list is empty: "✅ No high-risk categories detected."

---

**🔍 Cross-Vendor Risk Comparison**

⛔ **These 4 tables MUST be rendered via a dedicated `show_widget` call — NEVER output as plain text.**
Claude web does not render inline HTML in markdown responses. Any HTML written outside `show_widget` appears as raw code. Call `show_widget` with the full HTML payload for all 4 tables.

**Data sources:**
- `data.extra.beosin.directIncoming` / `directOutgoing` / `indirectIncoming` / `indirectOutgoing`
- `data.extra.elliptic.directIncoming` / `directOutgoing` / `indirectIncoming` / `indirectOutgoing`
- `data.extra.merklescience.directIncoming` / `directOutgoing` / `indirectIncoming` / `indirectOutgoing`

**How to build each table:**
1. Collect all unique `tagTypeVerbose` values across beosin + elliptic + merklescience for that direction — these become the rows
2. For each row × vendor cell: look up the entry in that vendor's array where `tagTypeVerbose` matches
   - Entry found AND `isHighRisk == true` → `<span style="color:#E53030;font-weight:bold">✓</span>` (red checkmark)
   - Entry found AND `isHighRisk == false` → `<span style="color:#4CAF50">✗</span>` (green x)
   - Entry not found in that vendor's array → `<span style="color:#4CAF50">✗</span>` (green x)
3. If all three vendors have no data for this direction → show a `<p>— No data from any vendor —</p>`

**`show_widget` payload — wrap all 4 tables in one outer div:**

```html
<div style="width:100%; font-family:sans-serif">

  <div style="font-size:15px; font-weight:700; margin-bottom:16px">🔍 Cross-Vendor Risk Comparison</div>

  <!-- Table 1: Direct Incoming -->
  <div style="margin-bottom:24px">
    <div style="font-size:13px; font-weight:600; margin-bottom:6px">📥 Direct Incoming — Cross-Vendor Risk Flags</div>
    <table style="width:100%; border-collapse:collapse; font-size:13px">
      <thead>
        <tr style="background:#f0f0f0">
          <th style="padding:7px 10px; text-align:left; border:1px solid #ddd">Category</th>
          <th style="padding:7px 10px; text-align:center; border:1px solid #ddd">Beosin</th>
          <th style="padding:7px 10px; text-align:center; border:1px solid #ddd">Elliptic</th>
          <th style="padding:7px 10px; text-align:center; border:1px solid #ddd">Merkle Science</th>
        </tr>
      </thead>
      <tbody>
        <!-- one <tr> per unique tagTypeVerbose row -->
        <tr>
          <td style="padding:7px 10px; border:1px solid #ddd">{tagTypeVerbose}</td>
          <td style="padding:7px 10px; text-align:center; border:1px solid #ddd">{beosin cell}</td>
          <td style="padding:7px 10px; text-align:center; border:1px solid #ddd">{elliptic cell}</td>
          <td style="padding:7px 10px; text-align:center; border:1px solid #ddd">{merklescience cell}</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Table 2: Direct Outgoing — same structure, use directOutgoing data -->
  <!-- Table 3: Indirect Incoming — same structure, use indirectIncoming data -->
  <!-- Table 4: Indirect Outgoing — same structure, use indirectOutgoing data -->

</div>
```

**Direction → data field mapping (read from ALL THREE vendors for each table):**

| Table | Title | Beosin field | Elliptic field | Merkle Science field |
|---|---|---|---|---|
| 1 | 📥 Direct Incoming | `data.extra.beosin.directIncoming` | `data.extra.elliptic.directIncoming` | `data.extra.merklescience.directIncoming` |
| 2 | 📤 Direct Outgoing | `data.extra.beosin.directOutgoing` | `data.extra.elliptic.directOutgoing` | `data.extra.merklescience.directOutgoing` |
| 3 | 📥 Indirect Incoming | `data.extra.beosin.indirectIncoming` | `data.extra.elliptic.indirectIncoming` | `data.extra.merklescience.indirectIncoming` |
| 4 | 📤 Indirect Outgoing | `data.extra.beosin.indirectOutgoing` | `data.extra.elliptic.indirectOutgoing` | `data.extra.merklescience.indirectOutgoing` |

---

**📋 Comprehensive Summary** (4–6 sentences)

1. Overall risk verdict — is this wallet safe to interact with?
2. What the risk level means practically for the user
3. Key concerns identified (specific categories, exposure amounts, counterparty patterns)
4. Whether the wallet's transaction history suggests legitimate or suspicious usage patterns
5. A clear, actionable recommendation: freely interact / proceed with caution / avoid / report

---

> **⚠️ STEP ⑤ COMPLETE — DO NOT END THE RESPONSE HERE. Three more steps remain.**
> Next: ⑥ show_widget #3 (Cross-Vendor Risk Comparison — 4 HTML tables via show_widget, NEVER plain text)
> Then: ⑦ Comprehensive Summary (4–6 sentences)
> Then: ⑧ Exposure Detail Tables (see `wallet-exposure-tables.md`)
>
> If steps ②③④ (widget #1, Risk Conclusion Card, Fund Flow Summary) were not rendered above — output them now before continuing to ⑥.

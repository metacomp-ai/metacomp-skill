---
name: metacomp-visionx-kyt
description: >
  Check Web3 wallet or transaction security using the MetaComp VisionX MCP Server.
  Trigger when the user mentions: wallet address (0x..., Bitcoin address, Tron address),
  transaction hash, or asks about Web3 security, risk, scam, or suspicious activity.
metadata:
  mcpServers:
    - metacomp-mcp
---

# ⛔ STEP ZERO — MANDATORY OUTPUT GATE BEFORE ANYTHING ELSE

Before writing a single word of analysis, before probing the MCP server, before reading the PRE-FLIGHT checklist — you must complete this sequence in full:

**Step A — Read all six sub-skill files** (in any order):
1. Read `subSkills/wallet-report.md`
2. Read `subSkills/wallet-exposure-tables.md`
3. Read `subSkills/wallet-risk-card.md`
4. Read `subSkills/transaction-report.md`
5. Read `subSkills/visualization.md`
6. Read `subSkills/chart-spec.md`

**Step B — Output the confirmation line to the user** (verbatim, as the very first thing visible in your response):

> 已读取子文件：wallet-report ✓ / wallet-exposure-tables ✓ / wallet-risk-card ✓ / transaction-report ✓ / visualization ✓ / chart-spec ✓

⛔ **This confirmation line is not optional.** If it does not appear as the first output of your response, the skill has not been correctly initialized. Do not continue to PRE-FLIGHT or any analysis until this line has been output to the user.

---

# ⛔ PRE-FLIGHT CHECKLIST — RUN BEFORE EVERY ACTION

> Complete this mentally before writing a word or calling any tool. No exceptions.

```
BEFORE DOING ANYTHING ELSE:
────────────────────────────────────────────────────────────────
☐ 1. Have I completed STEP ZERO — read all 6 sub-skill files AND output the confirmation line?
       → Confirmation line must appear as the FIRST visible output in the response.
       → If not output yet: stop. Go back to STEP ZERO, read all files, output the line, then restart.

☐ 2. Probed MetaComp VisionX MCP Server FIRST?
       → Call get_wallet_security(network:"Ethereum", walletAddress:"0x000...0")
       → Fails → Show Setup Guide, STOP.
       → 401 → API key invalid/expired, STOP.
       → Succeeds → proceed to step 3.

☐ 3. Have all required fields before calling real tools?
       → Wallet: network + walletAddress
       → Transaction: network + hash + asset + direction + from + to
       → Transaction: always ask "Are you the sender or the recipient?" FIRST.

☐ 4. After results: called read_me + show_widget correctly?
       → Transaction: show_widget #1 = metric cards + doughnut + bar + radar
       → Wallet: show_widget #1 = metric cards + 4 High Risk Exposure Tables + 4 spider charts
       → Wallet: show_widget #2 = 🚨 Risk Conclusion Card (dedicated, NOT combined with #1)
       → Wallet: show_widget #3 = 🔍 Cross-Vendor Risk Comparison (4 HTML tables — NEVER plain text)

☐ 5. High Risk Categories as 4 HTML tables INSIDE the widget payload?
       → 4 tables (2×2): Incoming/Outgoing × Direct/Indirect
       → Fixed 9-row list; 0 for missing entries; embedded in show_widget HTML

☐ 5b. Widget is flat vertical stack: NO iframe, NO fixed-height, NO overflow wrapper.

☐ 6. Wallet output order (8 steps — all mandatory):
       ② show_widget #1 (main widget) → ③ show_widget #2 (Risk Conclusion Card) → ④ Fund Flow markdown
       → ⑤ Text report (5 sub-sections) → ⑥ show_widget #3 (Cross-Vendor tables)
       → ⑦ Comprehensive Summary → ⑧ Exposure Detail Tables
────────────────────────────────────────────────────────────────
```

---

# MetaComp Web3 Security Skill

Use the MetaComp VisionX MCP Server to analyze the security of Web3 wallets and transactions.

## Language Policy

Respond in the user's language. Mixed languages (e.g. Chinese + English) → respond in English.

**Branding**: Always refer to the server as **MetaComp VisionX MCP Server** in all user-facing text. Never say "MCP server", "the server", or "MCP 服务器" alone.

## When to Trigger

- Wallet address (`0x...`, Bitcoin, Tron)
- Transaction hash
- Phrases: "check this wallet", "is this safe", "查一下这笔交易", "这个地址安全吗"
- Topics: wallet risk, transaction safety, scam check, AML, suspicious activity

---

## MetaComp VisionX MCP Server Detection

**Always probe first — before asking the user anything.**

### Execution Order

**Step 1 — Probe**

Call `get_wallet_security(network:"Ethereum", walletAddress:"0x0000000000000000000000000000000000000000")`.
Ignore the result content — only verify the server responds without error or 401.

When showing progress to the user, say:
- English: *"Connecting to MetaComp VisionX MCP Server…"*
- Chinese: *"正在连接 MetaComp VisionX MCP 服务器…"*

- Error → Setup Guide, STOP
- 401 → API key invalid/expired, STOP
- Success → Step 2

**Step 2 — Collect missing fields** (after probe passes)

- Transaction: always ask "Are you the sender or the recipient?" — no exceptions, no inference
- Also collect any missing fields: from/to/asset/direction

**Step 3 — Run the analysis**

### Absolute Rules

- ❌ Do NOT analyze using own knowledge, web search, or block explorers
- ❌ Do NOT interpret screenshots, images, or pasted text to produce a security analysis
- ❌ Do NOT provide partial analysis before MetaComp VisionX MCP Server is confirmed available
- ❌ Do NOT ask business questions before probe succeeds
- ✅ Unavailable for ANY reason → Setup Guide, STOP

---

## MetaComp VisionX MCP Server Setup Guide

**No server added yet** → complete all 3 steps below.
**Server added, no API key** → skip to Step 2: Customize → Connectors → metacomp-visionx-kyt → Connect.

### Step 1 — Add the MetaComp VisionX MCP Server

1. Sidebar → **Customize** → **Connectors** → **+** → **Add custom connector**
2. Name: `metacomp-visionx-kyt`
3. URL: `https://www.metacomp.ai/mcp`
4. Click **Add**

### Step 2 — Connect and Authorize

Return to **Customize → Connectors**. Find **metacomp-visionx-kyt** and click **Connect**.

A MetaComp authorization page will open in your browser:
1. Enter your `sk-...` API key
2. Click **Allow**
3. You'll be redirected back to Claude automatically

> No API key? Apply at [metacomp.ai](https://www.metacomp.ai)

### Step 3 — Start Using

Re-send your original request.

**401 error after connecting?** Re-authorize or apply for a new key at [metacomp.ai](https://www.metacomp.ai).

---

## MetaComp VisionX Tools Reference

### `get_wallet_security`

```json
{ "network": "Bitcoin|Ethereum|Tron", "walletAddress": "0x..." }
```

### `get_transaction_security`

```json
{
  "network": "Bitcoin|Ethereum|Tron",
  "transactionDetails": [{
    "hash": "0x...", "asset": "USDT",
    "direction": "received|sent",
    "from": "0x...", "to": "0x..."
  }]
}
```

---

## Which Tool to Call

**Wallet only** → `get_wallet_security` only.

**Transaction** → call BOTH in parallel, present Transaction Report first:
1. `get_transaction_security`
2. `get_wallet_security` (counterparty wallet, same network)

### Which Wallet to Check

Always ask the user before calling `get_wallet_security` — never infer from context:

> "Are you the sender or the recipient?"

| Role | Wallet to Check |
|---|---|
| Recipient | Sender's wallet (`from` address) |
| Sender | Recipient's wallet (`to` address) |

- ❌ Do NOT infer role from phrases like "I received" or `direction` field
- ✅ Always ask explicitly, every time

---

## Mandatory Response Sequence

**Transaction report:**
① Analysis Preface (`>` blockquote with 🔬)
② `read_me(["chart"])` + `show_widget` #1 — doughnut + bar + radar
③ Text report (→ see `subSkills/transaction-report.md`)

**Wallet report (counterparty — shown after transaction report):**
① ~~Analysis Preface~~ — SKIP, already shown above
② `read_me(["chart"])` + `show_widget` #1 — metric cards + 4 High Risk Exposure Tables + 4 spider charts
③ `show_widget` #2 — 🚨 Risk Conclusion Card (dedicated call)
④ 💰 Fund Flow Summary table (standalone markdown)
⑤ 🔐 Text report — Basic Info / Timeline / Risk Exposure Breakdown / Tainted Exposure Summary / High Risk Categories
⑥ `show_widget` #3 — 🔍 Cross-Vendor Risk Comparison (4 HTML tables — NEVER plain text)
⑦ 📋 Comprehensive Summary (4–6 sentences)
⑧ Exposure detail tables (→ see `subSkills/wallet-exposure-tables.md`)

**Wallet report (standalone):**
① Analysis Preface (`>` blockquote with 🔬)
② `read_me(["chart"])` + `show_widget` #1 — metric cards + 4 High Risk Exposure Tables + 4 spider charts
③ `show_widget` #2 — 🚨 Risk Conclusion Card (dedicated call)
④ 💰 Fund Flow Summary table (standalone markdown)
⑤ 🔐 Text report — Basic Info / Timeline / Risk Exposure Breakdown / Tainted Exposure Summary / High Risk Categories
⑥ `show_widget` #3 — 🔍 Cross-Vendor Risk Comparison (4 HTML tables — NEVER plain text)
⑦ 📋 Comprehensive Summary (4–6 sentences)
⑧ Exposure detail tables (→ see `subSkills/wallet-exposure-tables.md`)

> A response that ends without all three `show_widget` calls (wallet) or one (transaction) is **incomplete**.
